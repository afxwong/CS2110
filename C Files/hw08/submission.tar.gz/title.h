#ifndef TITLE_H
#define TITLE_H

void drawTitleScreen(void);
int handleTitleTransition(unsigned int prevButtons, unsigned int currButtons);

#endif