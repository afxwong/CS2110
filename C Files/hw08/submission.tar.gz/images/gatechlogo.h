/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 gatechlogo gatechlogo.jpg 
 * Time-stamp: Tuesday 11/09/2021, 18:56:55
 * 
 * Image Information
 * -----------------
 * gatechlogo.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GATECHLOGO_H
#define GATECHLOGO_H

extern const unsigned short gatechlogo[38400];
#define GATECHLOGO_SIZE 76800
#define GATECHLOGO_LENGTH 38400
#define GATECHLOGO_WIDTH 240
#define GATECHLOGO_HEIGHT 160

#endif

