#ifndef TOPBAR_H
#define TOPBAR_H

void drawTimer(int time);
void drawHearts(int hearts);

#endif