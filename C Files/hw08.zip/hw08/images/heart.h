/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=10x10 heart heart.jpg 
 * Time-stamp: Monday 11/08/2021, 16:45:14
 * 
 * Image Information
 * -----------------
 * heart.jpg 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef HEART_H
#define HEART_H

extern const unsigned short heart[100];
#define HEART_SIZE 200
#define HEART_LENGTH 100
#define HEART_WIDTH 10
#define HEART_HEIGHT 10

#endif

