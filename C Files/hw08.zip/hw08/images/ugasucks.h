/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 ugasucks ugasucks.jpg 
 * Time-stamp: Tuesday 11/09/2021, 19:00:16
 * 
 * Image Information
 * -----------------
 * ugasucks.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef UGASUCKS_H
#define UGASUCKS_H

extern const unsigned short ugasucks[38400];
#define UGASUCKS_SIZE 76800
#define UGASUCKS_LENGTH 38400
#define UGASUCKS_WIDTH 240
#define UGASUCKS_HEIGHT 160

#endif

