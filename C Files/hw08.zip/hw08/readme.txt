Press enter to get into the game from the start screen.
You are the player that spawns on the left.
Controls for moving are the arrow keys.
You have three lives and lose one every time you hit a blocker.
Reach the right side of the screen as fast as possible for max score.
